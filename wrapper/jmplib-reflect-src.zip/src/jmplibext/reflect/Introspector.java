package jmplibext.reflect;

/**
 * This introspector is a reduced version of the JMPLib introspector so classes within the Java API can use the
 * version classes when making calls and using the instanceof operator. This code is aimed to generate a .jar that
 * is loaded as part of the VM Bootclasspath to be usable from Java API classes modified through ASM
 *
 * @author Jose Manuel Redondo López
 */
public class Introspector {
    private static java.lang.Class introspector = null;
    private static java.lang.reflect.Method instanceOf = null;
    private static java.lang.reflect.Method cast = null;

    static {
        try {
            //Precalculate values
            introspector = java.lang.Class.forName("jmplib.reflect.Introspector", true, ClassLoader.getSystemClassLoader());
            instanceOf = introspector.getMethod("instanceOf", Object.class, java.lang.Class.class);
            cast = introspector.getMethod("cast", java.lang.Class.class, Object.class);
        } catch (Exception ex) {
            //ex.printStackTrace();
        }
    }

    /**
     * Method equivalent to perform an instanceof
     *
     * @param obj   object to check
     * @param clazz Class to compare the object with
     * @return If the object is an instance of the class or not
     */
    public static boolean instanceOf(Object obj, java.lang.Class clazz) {

        try {
            return (boolean) instanceOf.invoke(null, obj, clazz);
        } catch (Exception ex) {
            //ex.printStackTrace();
        }

        return false;
    }

    /**
     * Some packages contain classes incompatible with the instrumentation we perform with ASM due to native calls,
     * integrity checks of the source code or recursive-call conditions. In these case we fallback to the standard
     * java reflection API to perform casts
     *
     * @param cl Class object
     * @return if this class supports our ASM instrumentation or not
     */
    private static boolean isUnsupportedClass(Class cl) {
        /*if (cl.getName().equals("java.lang.Object") || cl.getName().equals("java.lang.Thread") ||
                cl.getName().equals("java.util.concurrent.locks.ReentrantReadWriteLock"))
            return true;*/
        return cl.getPackage().getName().startsWith("java.lang") ||
                cl.getPackage().getName().startsWith("sun.") ||
                // ||
                cl.getPackage().getName().startsWith("com.intellij")
                || cl.getPackage().getName().startsWith("com.github.javaparser")
                || cl.getPackage().getName().startsWith("org.junit")
                || cl.getPackage().getName().startsWith("polyglot.");
    }

    /**
     * Cast obj to castTarget
     *
     * @param castTarget Class to cast to
     * @param obj        Object to cast
     * @return Casted object
     */
    public static Object cast(java.lang.Class castTarget, Object obj) {
        try {
            if (isUnsupportedClass(castTarget)) {
                if (obj == null)
                    return castTarget.cast(obj);
                else if (isUnsupportedClass(obj.getClass()))
                    return castTarget.cast(obj);
            }
            //System.out.println("castTarget = " + castTarget);
            //System.out.println("obj = " + obj);

            return cast.invoke(null, castTarget, obj);
        } catch (Exception ex) {
            return castTarget.cast(obj);
            //throw new ClassCastException("Cannot cast " + obj.getClass().getName() + " instance to " + castTarget.getName());
        }
    }
}
